
You can download the ArduinoISP firmware source files from:

https://github.com/arduino/ArduinoISP

